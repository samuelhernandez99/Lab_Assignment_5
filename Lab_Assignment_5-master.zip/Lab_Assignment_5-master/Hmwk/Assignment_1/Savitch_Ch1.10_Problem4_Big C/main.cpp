/* 
 * Author: 
 * Date:
 * Purpose:
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    
    char x;
    
    //Input or initialize values Here
    
    cout << "Input the character to make the Big C!\n" << endl;
    cin >> x;
    
    //Process/Calculations Here
    
    cout << "    " << x << " " << x << " " << x << endl
    << "   " << x << "     " << x << endl
    << "  " << x << endl << "  " << x << endl << "  " << x << endl << "  " << x << endl << "  " << x << endl <<
    "   " << x << "     " << x << endl << "    " << x << " " << x << " " << x << endl;
    
    //Output Located Here

    //Exit
    return 0;
}